# -*- coding: utf-8 -*-
import scrapy


class CoursesSpider(scrapy.Spider):
    name = 'courses'
    @property 
    def start_urls(self):
        url_templ='https://www.shiyanlou.com/courses/?category=all&course_type=all&fee=all&tag=all&page={}'
	return (url_teml.format(i) for i in range(1,23))

    allowed_domains = ['shiyanlou.com']
    

    def parse(self, response):
	for course in responses.css('div.course-body')
		item = CourseItem{
			'name':course.css('div-course-name::text').extract_first(),
			'description':course_css('div-course-desc::text').extract(),
			'type':course.css('div.course-footer span.pull-right::text').extract_first(default='free'),
			'students':course.xpath('.//span[contains(@class,"pull-left")]/text()[2]').re_first('[^\d]*(\d*)[\d]*')})
		yield item
        pass
