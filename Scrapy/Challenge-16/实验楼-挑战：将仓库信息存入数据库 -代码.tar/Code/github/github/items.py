# -*- coding: utf-8 -*-

import scrapy


class GithubItem(scrapy.Item):
    __tablename__ = 'repositories'
    id = scrapy.Field()
    name = scrapy.Field()
    update_time= scrapy.Field()
